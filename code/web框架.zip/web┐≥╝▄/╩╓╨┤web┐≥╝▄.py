import socket
import re

server = socket.socket()  # 创建服务端套接字
server.bind(("127.0.0.1", 8080))  # 绑定ip和端口
server.listen(5)  # 监听链接

"""
b'GET / HTTP/1.1\r\n
Host: 127.0.0.1:8080\r\n
Connection: keep-alive\r\n
Cache-Control: max-age=0\r\n
Upgrade-Insecure-Requests: 1\r\n
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36\r\n
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\r\n
Sec-Fetch-Site: none\r\n
Sec-Fetch-Mode: navigate\r\n
Sec-Fetch-User: ?1\r\n
Sec-Fetch-Dest: document\r\n
Accept-Encoding: gzip, deflate, br\r\n
Accept-Language: zh-CN,zh;q=0.9\r\n
\r\n'

"""

while True:
    conn, addr = server.accept()  # 接受链接
    data = conn.recv(1024)  # 接受数据
    conn.send(b"HTTP/1.1 200 OK\r\n\r\n")  # 返回响应头
    request_header = data.decode().split(" ")

    with open("templates/login.html", 'rb') as f:
        html = f.read()
    conn.send(html)  # 返回html文件
    if len(request_header) >= 2:
        conn.send(request_header[1].encode())  # 获得访问路径，并返回

    conn.close()  # 关闭链接

