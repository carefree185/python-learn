from wsgiref.simple_server import make_server
from urls import urls
from views import error


def run(env, response):
    """
    :param env: 一个字典，请求相关的所有数据以及其他相关数据
    :param response: 响应相关的所有数据
    :return: 返回给浏览器的数据
    """
    response("200 OK", [])
    current_path = env.get("PATH_INFO")
    # if current_path == "/index":
    #     with open("login.html", "rb") as f:
    #         return [f.read()]
    # else:
    #     return [b"404 error"]

    func = None
    for url in urls:
        if current_path in url:
            func = url[1]
            break  # 匹配到一个url后结束循环

    if func is not None:  # 循环结束后，可能存在func==None
        res = func(env)
    else:
        res = error(env)

    return [res.encode()]


if __name__ == '__main__':
    server = make_server("127.0.0.1", 8080, run)  # 实时监听指定地址，只要有客户链接就会出发run函数运行
    server.serve_forever()  # 启动服务的
