"""
路由与视图函数的的对应关系
"""

from views import *

# url与函数的对应
urls = [
    ("/index", index),
    ("/login", login),
    ("/xxx", xxx),
    ("/time", get_time),
    ("/get_dict", get_dict),
    ("/get_user", get_user)
]
