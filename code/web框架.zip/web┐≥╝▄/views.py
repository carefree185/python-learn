"""
存放视图函数
"""
import datetime
import pymysql
from jinja2 import Template


def index(env):
    return "index"


def login(env):
    return "login"


def xxx(env):
    return "xxx"


def error(env):
    return "404 ERROR"


def get_time(env):
    """
    获取时间返回给html
    :param env:
    :return:
    """
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %X")
    with open("templates/time.html", 'r', encoding="utf-8") as f:
        data = f.read()
        data = data.replace("xxx", current_time)  # 处理html文件，然后返回给前端

    return data


def get_dict(env):
    user_dict = {"username": "dyp", "age": 20}
    with open("templates/get_dict.html", "r", encoding="utf-8") as f:
        data = f.read()

    tmp = Template(data)
    res = tmp.render(user=user_dict)  # 给页面传值
    return res


def get_user(env):
    # 从数据库获取数据，通过模板语法处理后返回给html
    conn = pymysql.connect(
        host="127.0.0.1",
        port=3306,
        charset="utf8",
        user="root",
        password="dyp1996",
        database="djangodb",
        autocommit=True
    )

    cursor = conn.cursor(cursor=pymysql.cursors.DictCursor)
    sql = "select * from user"
    cursor.execute(sql)
    res_list = cursor.fetchall()
    print(res_list)
    # 将获取好的数据传递给html文件
    with open("templates/get_user.html", "r", encoding="utf-8") as f:
        data = f.read()
    tmp = Template(data)
    res = tmp.render(user_list=res_list)
    return res


if __name__ == '__main__':
    get_user("11")

