"""
主视图
"""
from .admin import admin_view
from .student import student_view
from .teacher import teacher_view

func_dic = {
    '1': admin_view,
    '2': student_view,
    '3': teacher_view,
}


def run():
    while True:
        print("""
        =======选课系统=======
            0. 结束
            1. 管理员
            2. 学生
            3. 讲师
        =========end========
        """)
        choice = input("请输入身份编号: ").strip()
        if choice == "0":
            return 0

        if choice not in func_dic:
            print("身份选择错误, 请重新确认")
            continue

        func_dic.get(choice)()
