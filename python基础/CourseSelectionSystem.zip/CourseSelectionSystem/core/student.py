"""
学员视图
"""
from lib import common
from interface import student_interface
from interface import common_interface

STUDENT_INFO = {
    "student": "",
}


def register():
    """学生注册"""
    while True:
        username = input("输入学生姓名: ").strip()
        password = input("输入学生密码: ").strip()
        re_pwd = input("重新输入密码: ").strip()

        while password != re_pwd:
            print("两次密码不一致, 重新输入")
            password = input("输入学生密码: ").strip()
            re_pwd = input("重新输入密码: ").strip()

        flag, msg = student_interface.student_register(username, password)
        if flag:
            print(msg)
            break
        else:
            print(msg)
            choice = input("是否退出注册, yes|no:").strip()
            if choice.casefold() in ('yes', 'y'):
                break


def login(func=None):
    """学生登录"""
    count = 0
    msg = ""
    while True:
        username = input("输入学生姓名: ").strip()
        while count < 3:
            password = input("输入学生密码: ").strip()
            flag, msg = student_interface.student_login(username, password)
            if flag:
                print(msg)
                STUDENT_INFO["student"] = username
                break
            else:
                print(msg)
                if msg == "密码错误":
                    count += 1
                else:
                    break
        else:
            print("密码错误超过三次")

        if msg == f"{username}不存在":
            continue
        break

    if func is not None:
        func()


@common.auth("student")
def choice_school():
    """学生选择学校"""
    while True:
        # 1. 获取学校
        flag, school_list = common_interface.get_all_school()
        if not flag:
            print(school_list)
            break
        print("编号: q: 退出选择学校")
        for index, school_name in enumerate(school_list):
            print(f"{'编号: %d' % index}:{'学校名: %s' % school_name}")

        # 选择学校编号
        choice = input("输入选择的学校编号: ").strip()
        if not choice.isdigit():
            if choice == 'q':
                break
            print("请输入输入数字")
            continue

        if choice := int(choice) not in range(len(school_list)):
            print(f"输入编号{choice}超出范围")
            continue

        school_name = school_list[choice]
        # 选择学校
        flag, msg = student_interface.choose_school(school_name, STUDENT_INFO.get("student"))
        if flag:
            print(msg)
            break
        else:
            print(msg)
            

@common.auth("student")
def choice_course():
    """学生选择学习课程"""
    while True:
        # 1. 获取当前学生所在学校的课程列表
        flag, course_list = student_interface.get_course_list(STUDENT_INFO.get("student"))
        if not flag:
            print(course_list)
            break
        # 2. 打印课程列表并让学生选择课程
        print("编号: q: 退出选择课程")
        for index, course_name in enumerate(course_list):
            print(f"{'编号: ', index}:{'课程名: ', course_name}")

        choice = input("输入课程编号: ").strip()
        if not choice.isdigit():
            if choice == "q":
                break
            print("输入必须为数字")
            continue

        if choice := int(choice) not in range(len(course_list)):
            print("输入有误")
            continue
        course_name = course_list[choice]  # 获取到课程名
        flag, msg = student_interface.choose_course(course_name, STUDENT_INFO.get("student"))
        if flag:
            print(msg)
            break
        else:
            print(msg)


@common.auth("student")
def check_score():
    """查看学习课程分数"""
    score = student_interface.chick_score(STUDENT_INFO.get("student"))
    if not score:
        print("没有选择课程")
    print(score)


func_dic = {
    "1": register,
    "2": login,
    "3": choice_school,
    "4": choice_course,
    "5": check_score,
}


def student_view():
    while True:
        print("""
        =======学员=======
            0. 退出
            1. 注册 
            2. 登录
            3. 选择校区
            4. 选择课程
            5. 查看分数
        ========end========
        """)
        choice = input("请输入功能编号: ").strip()
        if choice == "0":
            break
        if choice not in func_dic:
            print("功能选择错误, 请重新确认")
            continue

        func_dic.get(choice)()
