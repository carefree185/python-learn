"""
管理员视图
"""
from interface import admin_interface
from interface import common_interface
from lib import common


ADMIN_INFO = {
    "admin": "",
}


def register():
    """管理员注册"""
    while True:
        username = input("请输入用户名: ").strip()
        password = input("输入密码: ").strip()
        re_password = input("确认密码: ").strip()

        if password == re_password:
            # 调用管理员接口注册
            flag, msg = admin_interface.admin_register(username, password)
            if flag:
                print(msg)
                break
            else:
                print(msg)
        else:
            print("两次密码不一致, 请输入")
            choice = input("是否退出注册, yes|no:").strip()
            if choice.casefold() in ('yes', 'y'):
                break


def login(func=None):
    """管理员登录"""
    count = 0
    msg = ""
    while True:
        username = input("输入用户名: ").strip()
        while count < 3:
            password = input("输入密码: ").strip()
            flag, msg = admin_interface.admin_login(username, password)
            if flag:
                print(msg)
                # 记录当前登录状态
                ADMIN_INFO["admin"] = username
                break
            else:
                print(msg)
                if msg == "密码错误":
                    count += 1
                else:
                    break
        else:
            print("密码错误超过三次")

        if msg == f"{username}不存在":
            continue
        break

    if func is not None:
        func()


@common.auth("admin")
def create_school():
    """管理员创建学校"""
    while True:
        # 1. 输入要创建的学校
        school_name = input("输入学校名称: ").strip()
        school_address = input("输入学校地址: ").strip()

        # 2. 调用接口, 创建学校
        flg, msg = admin_interface.admin_create_school(school_name, school_address, ADMIN_INFO.get('admin'))
        if flg:
            print(msg)
            break
        else:
            print(msg)


@common.auth("admin")
def create_course():
    """管理员创建课程"""
    while True:
        # 1. 管理员先选择学校
        # 1.1 调用接口, 获取所有学校名称, 并打印
        flag, school_list_or_msg = common_interface.get_all_school()
        if not flag:
            print(school_list_or_msg)
            break

        for index, school_name in enumerate(school_list_or_msg):
            print(f"{index}: {school_name}")
        choice = input("输入学校编号: ").strip()
        if not choice.isdigit():
            print("请输入数字")
            continue

        choice = int(choice)
        if choice not in range(len(school_list_or_msg)):
            print("请输入正确编号")
            continue

        # 获取选择的学校
        school_name = school_list_or_msg[choice]

        # 2. 选择学校后再创建课程名称
        course_name = input("输入要创建的课程名称: ").strip()

        # 3. 调用创建课程接口, 创建课程
        flag, msg = admin_interface.admin_create_course(school_name, course_name, ADMIN_INFO.get("admin"))
        if flag:
            print(msg)
            break
        else:
            print(msg)


@common.auth("admin")
def create_teacher():
    """管理员创建讲师"""
    while True:
        teacher_name = input("输入老师的名字: ").strip()
        # 调用接口创建老师
        flag, msg = admin_interface.admin_create_teacher(teacher_name, ADMIN_INFO.get("admin"))
        if flag:
            print(msg)
            break
        else:
            print(msg)


func_dic = {
    "1": register,
    "2": login,
    "3": create_school,
    "4": create_course,
    "5": create_teacher,
}


def admin_view():
    while True:
        print("""
        =======管理员=======
            0. 退出
            1. 注册 
            2. 登录
            3. 创建学校
            4. 创建课程
            5. 创建讲师
        =========end========
        """)

        choice = input("请输入功能编号: ").strip()
        if choice == "0":
            break

        if choice not in func_dic:
            print("功能选择错误, 请重新确认")
            continue

        func_dic.get(choice)()
