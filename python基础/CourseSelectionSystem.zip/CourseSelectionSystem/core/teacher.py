"""
讲师视图
"""
from lib import common
from interface import teacher_interface
from interface import common_interface
from db import models

TEACHER_INFO = {
    "teacher": "",
}


def login(func=None):
    """教师登录"""
    count = 0
    msg = ""
    while True:
        username = input("输入用户名: ").strip()
        while count < 3:
            password = input("输入密码: ").strip()
            flag, msg = teacher_interface.teacher_login(username, password)
            if flag:
                print(msg)
                # 记录当前登录状态
                TEACHER_INFO["teacher"] = username
                break
            else:
                print(msg)
                if msg == "密码错误":
                    count += 1
                else:
                    break
        else:
            print("密码错误超过三次")

        if msg == f"{username}不存在":
            continue
        break

    if func is not None:
        func()


@common.auth("teacher")
def check_course():
    """查看教授课程"""
    flag, course_list = teacher_interface.teacher_check_course(TEACHER_INFO.get("teacher"))
    if flag:
        print(course_list)
    else:
        print(course_list)


@common.auth("teacher")
def choose_course():
    """选择教授课程"""
    while True:
        # 1. 选择讲授的学校
        flag, school_list = common_interface.get_all_school()
        if not flag:
            print(school_list)
            break
        print(f"{'编号: q'}:{'退出学校选择'}")
        for index, school_name in enumerate(school_list):
            print(f"{'编号： %d' % index}:{'学校: %s' % school_name}")
        choice = input("输入学校编号: ").strip()

        if not choice.isdigit():
            if choice == 'q':
                break
            print("输入必须为数字")
            continue

        if choice := int(choice) not in range(len(school_list)):
            print("输入有误")
            continue

        school_name = school_list[choice]
        # 2. 从学校中开设的课程中选择
        flag, course_list = common_interface.get_all_course(school_name)
        if not flag:
            print(course_list)
            break

        print(f"{'编号: q'}:{'退出课程选择'}")
        for index, course_name in enumerate(course_list):
            print(f"{'编号： %d' % index}:{'课程: %s' % course_name}")
        choice = input("输入课程编号: ").strip()

        if not choice.isdigit():
            if choice == 'q':
                break
            print("输入必须为数字")
            continue

        if choice := int(choice) not in range(len(course_list)):
            print("输入有误")
            continue
        course_name = course_list[choice]
        # 3. 将课程添加到老师课程列表中
        flag, msg = teacher_interface.teacher_choose_course(course_name, TEACHER_INFO.get("teacher"))
        if flag:
            print(msg)
            break
        else:
            print(msg)


@common.auth("teacher")
def chick_student():
    """查看选课学生"""
    while True:
        flag, course_list = teacher_interface.teacher_check_course(TEACHER_INFO.get("teacher"))
        if not flag:
            print(course_list)
            break
        # 1. 获取当前老师选择的课程
        print(f"{'编号: q'}:{'退出课程选择'}")
        for index, course_name in enumerate(course_list):
            print(f"{'编号： %d' % index}:{'课程: %s' % course_name}")
        choice = input("输入课程编号: ").strip()

        if not choice.isdigit():
            if choice == 'q':
                break
            print("输入必须为数字")
            continue

        if choice := int(choice) not in range(len(course_list)):
            print("输入有误")
            continue
        course_name = course_list[choice]
        # 2. 获取课程下的学生
        flag, student_list = teacher_interface.get_course_student(course_name, TEACHER_INFO.get("teacher"))
        if not flag:
            print(student_list)
            break
        else:
            print(f"选择课程{course_name}学生有: ", student_list)
            break


@common.auth("teacher")
def update_score():
    """修改学生分数"""
    # 1. 获取讲师教授的课程，并选择课程
    # 2. 获取学校该课程的学生，并选择学生
    while True:
        flag, course_list = teacher_interface.teacher_check_course(TEACHER_INFO.get("teacher"))
        if not flag:
            print(course_list)
            break
        # 1. 获取当前老师选择的课程
        print(f"{'编号: q'}:{'退出课程选择'}")
        for index, course_name in enumerate(course_list):
            print(f"{'编号： %d' % index}:{'课程: %s' % course_name}")
        choice = input("输入课程编号: ").strip()

        if not choice.isdigit():
            if choice == 'q':
                break
            print("输入必须为数字")
            continue

        if choice := int(choice) not in range(len(course_list)):
            print("输入有误")
            continue
        course_name = course_list[choice]
        # 2. 获取课程下的学生
        flag, student_list = teacher_interface.get_course_student(course_name, TEACHER_INFO.get("teacher"))
        if not flag:
            print(student_list)
            break
        print(f"{'编号: 0'}: {'退出学生选择'}")
        for index, student_name in enumerate(student_list):
            print(f"{'编号: %d' % index}:{'课程: %s' % student_name}")

        choice = input("选择学生编号: ").strip()
        if not choice.isdigit():
            if choice == 'q':
                break
            print("输入必须为数字")
            continue

        if choice := int(choice) not in range(len(student_list)):
            print("输入有误")
            continue

        student_name = student_list[choice]
        score = input("输入成绩: ").strip()
        if score.isdigit():
            score = int(score)
        # 调用接口，修改分数
        flag, msg = teacher_interface.teacher_update_score(course_name, student_name, score, TEACHER_INFO.get("teacher"))
        if flag:
            print(msg)
            break




func_dic = {
    "1": login,
    "2": check_course,
    "3": choose_course,
    "4": chick_student,
    "5": update_score,
}


def teacher_view():
    while True:
        print("""
        =======讲师=======
            0. 退出
            1. 登录
            2. 查询教授课程
            3. 选择教授课程
            4. 查看教授课程的学生
            5. 为学生修改课程分数
        ========end========
        """)
        choice = input("请输入功能编号: ").strip()
        if choice == "0":
            break
        if choice not in func_dic:
            print("功能选择错误, 请重新确认")
            continue

        func_dic.get(choice)()
