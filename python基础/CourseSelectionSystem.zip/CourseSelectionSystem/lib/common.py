"""
公共方法
"""


# 登录认证
def auth(role):
    """
    多用户登录认证
    :param role:  管理员， 学生， 讲师
    :return:
    """
    from core import admin, student, teacher

    def login_auth(func):
        def inner(*args, **kwargs):
            if role == "admin":
                if admin.ADMIN_INFO.get("admin"):
                    return func(*args, **kwargs)
                else:
                    admin.login(func)
            elif role == "student":
                if student.STUDENT_INFO.get("student"):
                    return func(*args, **kwargs)
                else:
                    student.login(func)

            elif role == "teacher":
                if teacher.TEACHER_INFO.get('teacher'):
                    return func(*args, **kwargs)
                else:
                    teacher.login(func)
            else:
                print("当前视图没有权限")
        return inner
    return login_auth
