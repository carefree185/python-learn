"""
存放类

# 角色
    * 学校
    * 学员
    * 课程
    * 讲师
"""
from .db_handlers import save_data
from .db_handlers import select_data


class Base:
    """
    每个类都要使用的公共方法
    """

    def save(self):
        """保存数据"""
        save_data(self)

    @classmethod
    def select(cls, username):
        """查询数据"""
        return select_data(cls, username)


class School(Base):
    """学校"""

    def __init__(self, name, address, admin_name):
        self.username = name
        self.address = address
        self.create_admin = admin_name
        self.course_list = []


class Student(Base):
    """学员"""
    def __init__(self, username, password):
        self.username = username
        self.password = password
        self.school = None  # 学生只能在一个校区
        self.choose_course_list = []  # 学生可以选择多个课程
        self.score = {}

    def choose_school(self, school_name):
        """选择学校"""
        self.school = school_name
        self.save()

    def choose_course(self, course_name):
        """选择课程"""
        self.choose_course_list.append(course_name)
        self.score[course_name] = 0
        self.save()

        # 课程对象添加学生
        course = Course.select(course_name)
        course.student_list.append(self.username)
        course.save()


class Teacher(Base):
    """讲师"""
    def __init__(self, teacher_name, password):
        self.username = teacher_name
        self.password = password
        self.course_list = []

    def check_course(self):
        """查看老师教授课程"""
        return self.course_list

    def choose_course(self, course_name):
        self.course_list.append(course_name)
        self.save()

    @staticmethod
    def get_student(course_name):
        """获取学生列表"""
        course = Course.select(course_name)
        return course.student_list

    def update_score(self, course_name, student_name, score):
        """修改课程分数"""
        # 1. 获取学生对象
        student = Student.select(student_name)
        student.score[course_name] = score
        student.save()


class Course(Base):
    """课程"""

    def __init__(self, course_name):
        self.username = course_name
        self.student_list = []


class Admin(Base):
    """管理员"""
    def __init__(self, username, password):
        self.username = username  # self.username 同一admin.username
        self.password = password

    def create_school(self, school_name, school_address):
        """创建学校"""
        school = School(school_name, school_address, self.username)
        school.save()

    @staticmethod
    def create_course(school, course_name):
        """创建课程"""
        # 1. 调用课程类, 创建课程
        course = Course(course_name)
        course.save()
        # 2. 添加课程到学校课程列表中
        school.course_list.append(course_name)
        # 3. 更新学校数据
        school.save()

    @staticmethod
    def create_teacher(teacher_name, password):
        """创建讲师"""
        teacher = Teacher(teacher_name, password)
        teacher.save()
