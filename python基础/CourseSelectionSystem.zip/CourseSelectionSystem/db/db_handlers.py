"""
保存对象和获取对象
"""
import pickle
import os
from conf import settings


def save_data(data):
    """保存对象"""
    # 1. 获取对象的保存文件路径
    # 1.1 以类名创建文件夹
    class_name = data.__class__.__name__  # 获取类名
    user_dir_path = os.path.join(
        settings.DB_PATH, class_name
    )
    # 1.2 判断文件夹是否存在
    if not os.path.exists(user_dir_path):
        os.mkdir(user_dir_path)

    # 1.3 以用户名作为文件名, 创建文件
    user_path = os.path.join(
        user_dir_path, data.username
    )
    # 1.4 打开文件保存对象
    with open(user_path, mode="wb") as f:
        f.write(pickle.dumps(data))
        f.flush()


def select_data(cls, username):
    """获取对象"""
    class_name = cls.__name__  # 获取类名
    user_dir_path = os.path.join(
        settings.DB_PATH, class_name
    )
    # 1.2 判断文件夹是否存在
    if not os.path.exists(user_dir_path):
        os.mkdir(user_dir_path)

    # 1.3 以用户名作为文件名, 创建文件
    user_path = os.path.join(
        user_dir_path, username
    )
    # 1.4 判断文件是否存在
    if os.path.exists(user_path):
        with open(user_path, mode="rb") as f:
            return pickle.load(f)

    return None
