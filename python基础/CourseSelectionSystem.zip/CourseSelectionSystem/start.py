from core import src


if __name__ == '__main__':
    src.run()
