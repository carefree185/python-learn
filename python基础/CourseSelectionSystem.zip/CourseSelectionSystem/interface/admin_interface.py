"""
管理员接口
"""
from db import models
from .common_interface import login, register


def admin_register(username, password):
    """管理员注册接口"""
    # # 1. 判断用户是否存在
    # admin = models.Admin.select(username)  # 获取用户
    #
    # # 1.1 存在, 不允许注册
    # if admin:
    #     return False, "用户名存在, 请重新输入"
    # # 1.2 不存在, 允许注册, 调用类实例化保存
    # admin = models.Admin(username, password)
    # admin.save()  # 把保存数据
    # return True, "注册成功"
    return register(username, password, models.Admin)


def admin_login(username, password):
    """管理员登录接口"""
    # # 1. 判断用户是否存在
    # admin = models.Admin.select(username)
    # # 1.1. 不存在返回给视图层
    # if not admin:
    #     return False, "用户不存在"
    # # 1.2 存在校验密码
    # if admin.password == password:
    #     return True, "登录成功"
    # else:
    #     return False, "密码错误"
    return login(username, password, models.Admin)


def admin_create_school(school_name, school_address, admin_name):
    """管理员创建学校"""
    # 1. 查看学校是否存在
    school = models.School.select(school_name)
    # 2. 存在则不允许创建
    if school:
        return False, "学校已存在"

    # 3. 不存在则创建学校（由管理员对象创建）

    admin = models.Admin.select(admin_name)
    admin.create_school(school_name, school_address)
    return True, f"学校{school_name}创建成功"


def admin_create_course(school_name, course_name, admin_name):
    """管理员创建课程"""
    # 1. 查看课程是否存在, 获取学校中的课程列表
    school = models.School.select(school_name)
    # 2. 判断当前课程是否存在课程列表中
    if course_name in school.course_list:
        return False, "课程已存在"
    # 3. 课程不存在创建课程

    admin = models.Admin.select(admin_name)
    admin.create_course(school, course_name)
    return True, f"课程{course_name}创建成功, 绑定到{school_name}"


def admin_create_teacher(teacher_name, admin_name, password="111"):
    """管理员创建老师"""
    teacher = models.Teacher.select(teacher_name)
    if teacher:
        return False, "讲师已存在"

    admin = models.Admin.select(admin_name)
    admin.create_teacher(teacher_name, password)

    return True, f"讲师{teacher_name}创建成功"
