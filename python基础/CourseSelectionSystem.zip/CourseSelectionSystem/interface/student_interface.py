"""
学生接口
"""
from db import models
from .common_interface import login, register


def student_register(username, password):
    """学生注册接口"""
    # # 1. 判断学生是否存在
    # student = models.Student.select(username)
    #
    # # 2. 如果存在, 不允许注册
    # if student:
    #     return False, f"学生{username}已存在, 不允许注册"
    #
    # # 3. 不存在运行运行注册
    # student = models.Student(username, password)
    # student.save()
    # return True, f"学生{username}注册成功"
    return register(username, password, models.Student)


def student_login(username, password):
    """学生登录接口"""
    # # 1. 查询学生是否存在,
    # student = models.Student.select(username)
    # if not student:
    #     return False, f"学生{username}不存在"
    #
    # if student.password == password:
    #     return True, "登录成功"
    # else:
    #     return False, "密码错误"
    return login(username, password, models.Student)


def choose_school(school_name, student_name):
    """学生选择学校接口"""
    student = models.Student.select(student_name)
    if student.school:
        return False, f"当前学生{student_name}已选择学校"

    student.choose_school(school_name)

    return True, f"学生选择学校{school_name}完成"


def get_course_list(student_name):
    """获取学生正在学习的课程列表"""
    # 1. 获取当前学生对象
    student = models.Student.select(student_name)
    # 判断学生是否选择学校
    if not student.school:
        return False, "未选择学校，请选择学校"

    # 或学校对象中的课程列表
    school = models.School.select(student.school)
    if not school.course_list:
        return False, "没有课程，联系管理员"

    return True, school.course_list


def choose_course(course_name, student_name):
    """学生选择课程"""
    # 1. 判断当前课程是否存在于学生课程列表中
    student = models.Student.select(student_name)

    if course_name in student.choose_course_list:
        return False, "该课程已经被学生选择"

    # 2. 调用学生对象中添加课程的方法
    student.choose_course(course_name)
    return True, f"课程{course_name}添加成功"


def chick_score(student_name):
    """查看分析"""
    student = models.Student.select(student_name)
    if student.score:
        return student.score
