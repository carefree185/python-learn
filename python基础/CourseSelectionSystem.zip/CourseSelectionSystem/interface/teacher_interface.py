from .common_interface import login
from db import models


def teacher_login(username, password):
    # # 1. 判断用户是否存在
    # teacher = models.Teacher.select(username)
    # # 1.1. 不存在返回给视图层
    # if not teacher:
    #     return False, "用户不存在"
    # # 1.2 存在校验密码
    # if teacher.password == password:
    #     return True, "登录成功"
    # else:
    #     return False, "密码错误"
    return login(username, password, models.Teacher)


def teacher_check_course(teacher_name):
    """查看课程"""
    teacher = models.Teacher.select(teacher_name)
    course_list = teacher.check_course()
    if not course_list:
        return False, "讲师未选择要教受的课程"
    return True, course_list


def teacher_choose_course(course_name, teacher_name):
    """讲师学者课程"""
    # 1. 获取当前老师对象，并判断老师是否选择课程
    teacher = models.Teacher.select(teacher_name)
    if course_name in teacher.course_list:
        return False, "讲师已经选择"
    # 2. 添加课程
    teacher.choose_course(course_name)
    return True, "添加课程成功"


def get_course_student(course_name, teacher_name):
    """获取课程下的学生列表"""
    teacher = models.Teacher.select(teacher_name)
    student_list = teacher.get_student(course_name)
    if not student_list:
        return False, f"课程{course_name}未被学生选择"

    return True, student_list


def teacher_update_score(course_name, student_name, score, teacher_name):
    """讲师修改分数"""
    teacher = models.Teacher.select(teacher_name)

    teacher.update_score(course_name, student_name, score)

    return True, "分数修改成功"
