"""
公共接口
"""
import os
from conf import settings
from db import models


def get_all_school():
    # 1. 拼接学校目录
    school_dir = os.path.join(settings.DB_PATH, "School")
    # 2. 判断学校目录是否存在
    if not os.path.exists(school_dir):
        return False, "没有学校, 请先联系管理员创建学校"
    # 3. 获取文件名
    school_list = os.listdir(school_dir)
    return True, school_list


def register(username, password, user_type):
    """公告注册接口"""
    # 1. 判断用户是否存在
    user = user_type.select(username)  # 获取用户

    # 1.1 存在, 不允许注册
    if user:
        return False, "用户名存在, 请重新输入"
    # 1.2 不存在, 允许注册, 调用类实例化保存
    user = user_type(username, password)
    user.save()  # 把保存数据
    return True, "注册成功"


def login(username, password, user_type):
    """公共登录接口"""
    # 1. 查询用户是否存在,
    user = user_type.select(username)
    if not user:
        return False, f"{username}不存在"

    if user.password == password:
        return True, "登录成功"
    else:
        return False, "密码错误"


def get_all_course(school_name):
    """获取学校下开始的课程列表"""
    # 1. 获取学校对象
    school = models.School.select(school_name)
    # 2. 获取课程
    if school.course_list:
        return True, school.course_list

    return False, "学校暂未开课"
